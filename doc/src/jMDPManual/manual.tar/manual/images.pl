# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate images original text with physical files.

$key = q/{_inline}$T_k(p,q)${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{gather}f_N(p)=opti_q_N[g_N(p_N,q_N)],{gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=407 HEIGHT=20 ALIGN=BOTTOM ALT="gather33" SRC="img5.gif"  > '; 
$key = q/{_inline}${q_1,dotsq_N}${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{_inline}$g_k(p,q)${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{gather}opti_G_N=g(p_0,p_1,dots,p_n;q_1,dotsq_N){gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=437 HEIGHT=19 ALIGN=BOTTOM ALT="gather18" SRC="img1.gif"  > '; 
$key = q/{gather}f_N(p)=h(p)qquadtext(Aknownfunction){gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=445 HEIGHT=19 ALIGN=BOTTOM ALT="gather45" SRC="img8.gif"  > '; 
$key = q/{_inline}$calQ(p_k,k)${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{_inline}$oplus${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{gather}f_N(p)=opti_{q_k}[G_N].k=1,dots,N{gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=430 HEIGHT=21 ALIGN=BOTTOM ALT="gather25" SRC="img3.gif"  > '; 
$key = q/{_inline}$G_N${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{gather}p_k+1=T_k(p_k,q_k)p_kincalP_kq_kincalQ(p_k,k){gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=367 HEIGHT=74 ALIGN=BOTTOM ALT="gather21" SRC="img2.gif"  > '; 
$key = q/{gather}f_k=opti_q_kleft[g_k(p_k,q_k)oplussum_p'f_k+1(p')P(p'|p,q)right],{gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=487 HEIGHT=64 ALIGN=BOTTOM ALT="gather39" SRC="img7.gif"  > '; 
$key = q/{gather}f_k=opti_q_kleft[g_k(p_k,q_k)oplusf_k+1(T_k(p_k,q_k))right]{gather}/;
$cached_env_img{$key} = ' <IMG WIDTH=456 HEIGHT=20 ALIGN=BOTTOM ALT="gather28" SRC="img4.gif"  > '; 
$key = q/{_inline}$calP_k${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{_inline}$P_k(p'|p,q)${_inline}/;
$cached_env_img{$key} = ''; 
$key = q/{_inline}$calQ(p_k,k)(p,k)${_inline}/;
$cached_env_img{$key} = ''; 

1;

